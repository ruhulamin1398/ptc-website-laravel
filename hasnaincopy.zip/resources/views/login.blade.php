<!doctype html>
<html lang="en">

<head>
    <meta charset=utf-8>
    <meta http-equiv=X-UA-Compatible content="IE=edge">
    <meta name=viewport content="width=device-width,initial-scale=1">
    <meta name=referrer content=no-referrer>
    <title>RbxAdder: Get FREE Robux Online</title>
    <meta name=Description content="Get Free Robux by installing apps and watching Videos, Min withdraw is only 1 Robux & Instant Payout. Join us and buy whatever you want in Roblox for Free!">
    <meta property=og:description content="Most Reliable way to get Free robux!">
    <meta property=og:title content="RbxAdder.com - Gain Free RBX">
    <meta property=og:image content=https://rbxadder.com/freerbx.jpg> <meta name=twitter:card content=summary_large_image>
    <meta name=twitter:title content="RbxAdder.com - Gain Free RBX">
    <meta name=twitter:description content="Gain Free Rbx by installing apps and completing surveys">
    <meta name=twitter:image content=https://rbxadder.com/freerbx.jpg> <meta name=propeller content=08a78b1eba469ca2041639952908f670>
    <meta name=ahrefs-site-verification content=645380b017556267467536cb9c634b0c816fb0ceba67d12346b27ee8081b4feb>
    <link rel=canonical href=https://www.rbxadder.com/> <link rel=icon href=favicon.ico>
    <link href="https://fonts.googleapis.com/css?family=Roboto:100:300,400,500,700,900|Material+Icons" rel=stylesheet>

    <link href="{{asset('css/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">


    <link href="https://fonts.googleapis.com/css?family=Roboto:100:300,400,500,700,900|Material+Icons" rel=stylesheet>

    <link rel="stylesheet" href="{{asset('css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/style.css')}}">


    <link rel="stylesheet" href="{{asset('css/chunk-vendors.fc9d4d64.css')}}">
    <style>
        body {
            font-size: 130%;

            font-family: Roboto, sans-serif;
            line-height: 1.5;

        }

        .secondary {
            background-color: #fa7e27 !important;
            border-color: #fa7e27 !important;
        }

        .bgImage {
            background-image: url(" {{asset('/images/cardbg.png')}}");
        }

        .subheading {
            font-size: 18px !important;
            font-weight: 400;
        }

        .application {
            font-family: Roboto, sans-serif;
            line-height: 1.5;
        }


        @media only screen and (min-width: 992px) {
            #sidebarCollapse {
                display: none;
            }
        }

        @media only screen and (max-width: 992px) {
            #sidebarCollapse {
                display: block;
            }
        }
    </style>
</head>

<body style=" background: rgb(239, 243, 246) none repeat scroll 0% 0%;">




    <nav class="navbar navbar-expand-lg navbar-light bg-dark p-4 ">
        <div class="container-fluid">

            <button type="button" id="sidebarCollapse" class="btn btn-primary">
                <i class="fa fa-bars"></i>
                <span class="sr-only">Toggle Menu</span>
            </button>
            <span class="h1 text-white "> Title </span>

        </div>
    </nav>











    <div data-v-41d03d86="" class="container fill-height">
        <div data-v-41d03d86="" class="layout row wrap align-center justify-center">
            <div data-v-41d03d86="" class="flex md6">
                <div data-v-41d03d86="" class="v-card theme--light">


                    <nav class="navbar navbar-dark bg-dark bgImage ">
                        <h2 class="navbar-brand pl-4 text-light ">Enter your Roblox username </h2>

                    </nav>
                    <div data-v-41d03d86="" class="v-card__text mt-3"><i data-v-41d03d86="">All the robux you make will be sent to this username, so make sure its correct!</i>
                        <form action="{{route('peoples.store')}}" method="post" id="loginForm">
                            @csrf
                            <div data-v-41d03d86="" class="v-input v-text-field theme--light">
                                <div class="v-input__control">
                                    <div class="v-input__slot">
                                        <div class="v-text-field__slot">
                                            <input name="username" type="text" placeholder="User name "  >
                                        </div>
                                    </div>
                                    <div class="v-text-field__details">
                                        <div class="v-messages theme--light">
                                            <div class="v-messages__wrapper"></div>
                                        </div>
                                    </div>
                                </div>
                            </div><button data-v-41d03d86="" ctype="submit" type="button"  onclick="
                            
                            if(confirm(
                                'All the robux you make will be sent to this username, so make sure its correct!'
                                
                                )){
				document.getElementById('loginForm').submit();
			}
			else{
				event.preventDefault();
			}
			"  class="v-btn v-btn--block theme--dark secondary">
                                <div class="v-btn__content">Login</div>
                            </button>





                            <div data-v-41d03d86="" class="form-error-msg error--text">
                                <div data-v-41d03d86="" style="display: none;"></div>
                            </div>
                        </form>
                    </div>
                    <div data-v-41d03d86="" class="v-card__actions"></div>
                    <div data-v-41d03d86="" class="v-card__actions">
                        <div data-v-41d03d86="" class="spacer"></div>
                    </div>
                </div>
            </div>
        </div>
        <div data-v-41d03d86="" class="v-dialog__container" style="display: block;"></div>
    </div>










    <!-- main body  end here  -->
    <br><br><br><br>

    <!-- footer  -->
    <footer class="v-footer v-footer--inset theme--light" style="height: auto;">
        <div class="text-xs-center v-card v-card--flat v-card--tile theme--light" style="width: 100%; background: rgb(239, 243, 246) none repeat scroll 0% 0%; color: rgb(136, 136, 136);">
            <div class="v-card__text"><a href="#/privacy" class="mx-1">Privacy Policy</a>-
                <a href="#/terms" class="mx-1">Terms of Service</a></div>
            <div class="v-card__text pt-0">
                We are not affiliated with any of the games or companies shown on
                this website. Use of any logos or trademarks are for reference
                purposes only. By utilizing the website, you agree to be bound by
                the terms of service.
            </div>
            <hr class="v-divider theme--light">
            <div class="v-card__text">
                ©2020 —
                <strong>RbxAdder</strong></div>
        </div>
    </footer>
    </div>
    </div>
    <i class="fas fa-user">
        <script src="{{asset('js/jquery.min.js')}}"></script>
        <script src="{{asset('js/popper.js')}}"></script>
        <script src="{{asset('js/bootstrap.min.js')}}"></script>
        <script src="{{asset('js/main.js')}}"></script>




</body>

</html>