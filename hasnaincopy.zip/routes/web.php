<?php

use App\people;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware' => 'login'], function (){



Route::get('/', function () {
    return view('welcome');
})->name('index');

Route::get('/cashout', function () {
    return view('cashout');
})->name('cashout');


Route::get('/invite', function () {
    return view('invite');
})->name('invite');


Route::get('/help', function () {
    return view('help');
})->name('help');


Route::get('/promo', function () {
    return view('promo');
})->name('promo');

Route::get('/mediap', function () {
    return view('media');
})->name('media');

Route::get('/points/{point}/{url}', function ($point,$url) {

    
    $people = App\people::find($_SESSION["id"]);
    $people->earn += (float)$point ; 
    $people->save();
    return redirect('http://'.$url);
})->name('points');




route::get('logout',function(){
 
    session_destroy();
    return back();

})->name('logout');

});


route::get('login',function(){
    return view('login');

})->name('login');
route::resource('peoples','PeopleController');